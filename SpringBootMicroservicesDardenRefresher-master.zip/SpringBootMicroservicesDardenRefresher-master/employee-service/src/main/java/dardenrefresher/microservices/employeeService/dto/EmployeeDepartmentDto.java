package dardenrefresher.microservices.employeeService.dto;

import dardenrefresher.microservices.employeeService.entity.Employee;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDepartmentDto {
    private EmployeeDto employee;
    private DepartmentDto department;
}

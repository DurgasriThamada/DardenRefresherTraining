package dardenrefresher.microservices.employeeService.service;

import dardenrefresher.microservices.employeeService.dto.EmployeeDepartmentDto;
import dardenrefresher.microservices.employeeService.dto.EmployeeDto;

public interface EmployeeService {
    EmployeeDto saveEmployee(EmployeeDto employeeDto);

    EmployeeDepartmentDto getEmployeeById(long id);
}

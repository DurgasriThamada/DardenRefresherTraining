package dardenrefresher.microservices.employeeService.controller;

import dardenrefresher.microservices.employeeService.dto.EmployeeDepartmentDto;
import dardenrefresher.microservices.employeeService.dto.EmployeeDto;
import dardenrefresher.microservices.employeeService.service.EmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/employees")
@AllArgsConstructor
public class EmployeeController {
    private EmployeeService employeeService;

    @PostMapping
    public ResponseEntity<EmployeeDto> saveEmployee(@RequestBody EmployeeDto employeeDto){
        EmployeeDto savedEmployeeDto = employeeService.saveEmployee(employeeDto);
        return new ResponseEntity<>(savedEmployeeDto, HttpStatus.CREATED);
    }

    @GetMapping("{employee-id}")
    public ResponseEntity<EmployeeDepartmentDto> getEmployeeById(@PathVariable("employee-id") Long id){
        EmployeeDepartmentDto employeeDepartmentDto = employeeService.getEmployeeById(id);
        return new ResponseEntity<>(employeeDepartmentDto, HttpStatus.OK);
    }

}

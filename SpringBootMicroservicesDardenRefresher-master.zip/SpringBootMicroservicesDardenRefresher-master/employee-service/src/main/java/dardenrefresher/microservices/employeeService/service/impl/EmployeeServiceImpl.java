package dardenrefresher.microservices.employeeService.service.impl;

import dardenrefresher.microservices.employeeService.dto.DepartmentDto;
import dardenrefresher.microservices.employeeService.dto.EmployeeDepartmentDto;
import dardenrefresher.microservices.employeeService.dto.EmployeeDto;
import dardenrefresher.microservices.employeeService.entity.Employee;
import dardenrefresher.microservices.employeeService.exception.ResourceNotFoundException;
import dardenrefresher.microservices.employeeService.mapper.EmployeeMapper;
import dardenrefresher.microservices.employeeService.mapper.EmployeeMapperMapStruct;
import dardenrefresher.microservices.employeeService.repository.EmployeeRepository;
import dardenrefresher.microservices.employeeService.service.DepartmentFeignClient;
import dardenrefresher.microservices.employeeService.service.EmployeeService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;


@Service
@AllArgsConstructor
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
//    private RestTemplate restTemplate;
//    private WebClient webClient;
    private DepartmentFeignClient departmentFeignClient;
    static final Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);
    @Override
    public EmployeeDto saveEmployee(EmployeeDto employeeDto) {
        Employee employee = EmployeeMapper.mapToEmployee(employeeDto);//ModelMapper
        logger.info(".....!"+employee.toString());
//        Employee employee = EmployeeMapperMapStruct.MAPPER.mapToEmployee(employeeDto);
        Employee savedEmployee = employeeRepository.save(employee);
        EmployeeDto savedEmployeeDto = EmployeeMapper.mapToEmployeeDTO(savedEmployee);
//        EmployeeDto savedEmployeeDto = EmployeeMapperMapStruct.MAPPER.mapToEmployeeDTO(savedEmployee);
        return savedEmployeeDto;
    }

    @CircuitBreaker(name = "${spring.application.name}", fallbackMethod = "getDefaultDepartment")
    @Override
    public EmployeeDepartmentDto getEmployeeById(long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow(
                ()-> new ResourceNotFoundException("Employee","id",id)
        );
        EmployeeDto employeeDto = EmployeeMapper.mapToEmployeeDTO(employee);
//        EmployeeDto employeeDto = EmployeeMapperMapStruct.MAPPER.mapToEmployeeDTO(employee);
//        EmployeeDto employeeDto= new EmployeeDto(
//                employee.getId(),
//                employee.getFirstName(),
//                employee.getLastName(),
//                employee.getEmail()
//        );

//        ResponseEntity<DepartmentDto> responseEntity= restTemplate.getForEntity("http://localhost:8080/api/departments/"+employeeDto.getDepartmentCode(),DepartmentDto.class);
//        DepartmentDto departmentDto = responseEntity.getBody();

//        DepartmentDto departmentDto = webClient.get()
//                                            .uri("http://localhost:8080/api/departments/"+employeeDto.getDepartmentCode())
//                                            .retrieve()
//                                            .bodyToMono(DepartmentDto.class)
//                                            .block();

        DepartmentDto departmentDto = departmentFeignClient.getDepartment(employeeDto.getDepartmentCode());
//        DepartmentDto departmentDto = new DepartmentDto();
            return new EmployeeDepartmentDto(employeeDto,departmentDto);
    }

    public EmployeeDepartmentDto getDefaultDepartment(long id, Exception exception) {
        Employee employee = employeeRepository.findById(id).orElseThrow(
                ()-> new ResourceNotFoundException("Employee","id",id)
        );
        EmployeeDto employeeDto = EmployeeMapper.mapToEmployeeDTO(employee);
        DepartmentDto departmentDto = new DepartmentDto();
        departmentDto.setDepartmentCode("CSE001");
        departmentDto.setDepartmentDescription("Computer science");
        departmentDto.setDepartmentName("CSE");

        return new EmployeeDepartmentDto(employeeDto,departmentDto);
    }
}

package dardenrefresher.microservices.employeeService.mapper;

import dardenrefresher.microservices.employeeService.dto.EmployeeDto;
import dardenrefresher.microservices.employeeService.entity.Employee;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface EmployeeMapperMapStruct {
    EmployeeMapperMapStruct MAPPER = Mappers.getMapper(EmployeeMapperMapStruct.class);

    EmployeeDto mapToEmployeeDTO(Employee employee);

    Employee mapToEmployee(EmployeeDto employeeDto);
}

package dardenrefresher.microservices.organizationService.mapper;

import dardenrefresher.microservices.organizationService.dto.OrganizationDto;
import dardenrefresher.microservices.organizationService.entity.Organization;

import java.time.LocalDateTime;

public class OrganizationMapper {
    public static Organization mapToOrganization(OrganizationDto organizationDto) {
        Organization organization = new Organization(
                organizationDto.getId(),
                organizationDto.getOrganizationName(),
                organizationDto.getOrganizationDescription(),
                organizationDto.getOrganizationCode(),
                LocalDateTime.now()
                );
        return  organization;
    }

    public static OrganizationDto mapToOrganizationDto(Organization organization){
        OrganizationDto organizationDto = new OrganizationDto(
                organization.getId(),
                organization.getOrganizationName(),
                organization.getOrganizationDescription(),
                organization.getOrganizationCode(),
                LocalDateTime.now()
        );
        return organizationDto;
    }
}

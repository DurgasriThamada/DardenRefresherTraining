package dardenrefresher.microservices.organizationService.service.impl;

import dardenrefresher.microservices.organizationService.dto.OrganizationDto;
import dardenrefresher.microservices.organizationService.entity.Organization;
import dardenrefresher.microservices.organizationService.mapper.OrganizationMapper;
import dardenrefresher.microservices.organizationService.repository.OrganizationRepository;
import dardenrefresher.microservices.organizationService.service.OrganizationService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class OrganizationServiceImpl implements OrganizationService {
    private OrganizationRepository organizationRepository;

    @Override
    public OrganizationDto saveOrganization(OrganizationDto organizationDto) {
        Organization organization = OrganizationMapper.mapToOrganization(organizationDto);
        Organization savedOrganization = organizationRepository.save(organization);
        OrganizationDto savedOrganizationDto = OrganizationMapper.mapToOrganizationDto(savedOrganization);
        return organizationDto;
    }
}

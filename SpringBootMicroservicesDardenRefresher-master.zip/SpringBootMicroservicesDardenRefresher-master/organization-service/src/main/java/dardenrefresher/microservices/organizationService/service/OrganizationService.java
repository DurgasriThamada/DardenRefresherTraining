package dardenrefresher.microservices.organizationService.service;

import dardenrefresher.microservices.organizationService.dto.OrganizationDto;

public interface OrganizationService {
    OrganizationDto saveOrganization(OrganizationDto  organizationDto);
}

package dardenrefresher.microservices.departmentService.service.impl;

import dardenrefresher.microservices.departmentService.dto.DepartmentDto;
import dardenrefresher.microservices.departmentService.entity.Department;
import dardenrefresher.microservices.departmentService.exception.ResourceNotFoundException;
import dardenrefresher.microservices.departmentService.mapper.DepartmentMapper;
import dardenrefresher.microservices.departmentService.mapper.DepartmentMapperMapStruct;
import dardenrefresher.microservices.departmentService.repository.DepartmentRepository;
import dardenrefresher.microservices.departmentService.service.DepartmentService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DepartmentServiceImpl implements DepartmentService {

    private DepartmentRepository departmentRepository;

    @Override
    public DepartmentDto saveDepartment(DepartmentDto departmentDto) {
        Department department = DepartmentMapper.mapToDepartment(departmentDto);
//        Department department = DepartmentMapperMapStruct.MAPPER.mapToDepartment(departmentDto);
        Department savedDepartment = departmentRepository.save(department);
        DepartmentDto savedDepartmentDto = DepartmentMapper.mapToDepartmentDTO(savedDepartment);
//        DepartmentDto savedDepartmentDto = DepartmentMapperMapStruct.MAPPER.mapToDepartmentDTO(savedDepartment);
        return savedDepartmentDto ;
    }

    @Override
    public DepartmentDto getDepartmentByCode(String code) {
        Department department = departmentRepository.findByDepartmentCode(code);
        if(department.equals(null))
            throw new ResourceNotFoundException("Department"," Code",code);
        DepartmentDto departmentDto = DepartmentMapper.mapToDepartmentDTO(department);
//        DepartmentDto departmentDto = DepartmentMapperMapStruct.MAPPER.mapToDepartmentDTO(department);
        return departmentDto;
    }
}

package dardenrefresher.microservices.departmentService.mapper;

import dardenrefresher.microservices.departmentService.dto.DepartmentDto;
import dardenrefresher.microservices.departmentService.entity.Department;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DepartmentMapperMapStruct {
    DepartmentMapperMapStruct MAPPER = Mappers.getMapper(DepartmentMapperMapStruct.class);

    public Department mapToDepartment(DepartmentDto departmentDto);

    public DepartmentDto mapToDepartmentDTO(Department department);
}
